Pour l’Ex4, nous avons eu l'idée de recréer un mini jeu de mario 64 DS : "loves me... loves me not".
Le jeu de base est de retirer les pétales jusqu’à ne plus en avoir et découvrir le message final.
Pour refaire le mini jeu, on a recréé une DS avec une vidéo qui se joue en boucle (ce qui permet d'animer le jeu et de mettre la musique), 
malheureusement la vidéo ne se lance pas sue Google Chrome.
Ensuite il a fallu changer dans l'html et le css : le bouton en une image du pistil, changer les branches d'étoiles en pétale et ajouté une nouvelle image avec le message.
Dans le jss la fonction supprimer change l'image du pistil et du message au hasard.

Notice :
Il suffit de cliquer sur le pistil pour rajouter des pétales et de cliquer sur celle-ci pour changer l’expression du pistil et le message.

C'est une fonctionnalité peu utile mais pour nous elle nous renvoie un sentiment de nostalgie et permet de rejouer a ce mini jeu.
